package pl.maciejwasiak.snake;

public enum Kierunki {
    UP,
    DOWN,
    LEFT,
    RIGHT
}
